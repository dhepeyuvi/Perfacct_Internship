/*****************************************************************************
 * Use EMA by including this header file::
 *
 *  #include <EMA.h>
 ****************************************************************************/
#ifndef EMA_H
#define EMA_H

#include <EMA/user.h>

#endif
